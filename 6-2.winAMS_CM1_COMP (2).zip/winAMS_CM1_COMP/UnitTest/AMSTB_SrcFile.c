#ifdef WINAMS_STUB
#ifdef __cplusplus
extern "C" {
#endif

/* WINAMS_STUB[main.c:func3_sub_read_io:AMSTB_func3_sub_read_io] */
int AMSTB_func3_sub_read_io( int index )
{
	static int retVal_func3_sub_read_io;
	return retVal_func3_sub_read_io;
}

#ifdef __cplusplus
}
#endif
#endif /* WINAMS_STUB */
